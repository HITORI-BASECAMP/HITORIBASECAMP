import { useState, useEffect } from "react";
import LP from "./lp_hitoribesecamp.jsx";
import DiagnosticApp from "./solo_life_skill_check_app_v6.jsx";
import LegalPages from "./legal_pages.jsx";

export default function App() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const handler = () => setPath(window.location.pathname);
    window.addEventListener("popstate", handler);
    return () => window.removeEventListener("popstate", handler);
  }, []);

  if (path === "/diagnostic") return <DiagnosticApp />;
  if (path.startsWith("/legal")) return <LegalPages />;
  return <LP />;
}
